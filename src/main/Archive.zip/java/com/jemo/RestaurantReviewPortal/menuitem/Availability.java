package com.jemo.RestaurantReviewPortal.menuitem;

public enum Availability {
    AVAILABLE,
    UNAVAILABLE
}
