package com.jemo.RestaurantReviewPortal.review;

public enum ReviewStatus {
    PENDING,
    APPROVED,
    REJECTED
}
