package com.jemo.RestaurantReviewPortal.user;

public enum UserRole {
    ADMIN,
    CUSTOMER
}
