package com.jemo.RestaurantReviewPortal.restaurant;

public enum RestaurantCuisine {
    BRITISH,
    ASIAN,
    CHINESE,
    AFRICAN,
    ITALIAN

}
