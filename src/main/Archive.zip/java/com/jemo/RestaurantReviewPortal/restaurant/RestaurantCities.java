package com.jemo.RestaurantReviewPortal.restaurant;

public enum RestaurantCities {
    STOKE,
    LONDON,
    GLASGOW,
    MANCHESTER,
    YORK,
    BATH,
    LIVERPOOL,
    BELFAST,
    OXFORD,
    EDINBURGH

}
