package com.jemo.RestaurantReviewPortal.menu;

public record MenuRequest(
        String name,
        String description
) {
}
