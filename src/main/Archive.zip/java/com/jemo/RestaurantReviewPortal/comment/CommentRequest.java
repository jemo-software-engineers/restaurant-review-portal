package com.jemo.RestaurantReviewPortal.comment;

public record CommentRequest(
        String commentText
) {}
