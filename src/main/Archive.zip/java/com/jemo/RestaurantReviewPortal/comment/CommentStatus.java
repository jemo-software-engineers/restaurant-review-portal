package com.jemo.RestaurantReviewPortal.comment;

public enum CommentStatus {
    PENDING,
    APPROVED,
    REJECTED
}
